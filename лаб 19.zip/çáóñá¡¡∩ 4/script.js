$(document).ready(function() {
  var checkboxes = $('input[type="checkbox"]');
  checkboxes.on('change', function() {
    var checkedCount = checkboxes.filter(':checked').length;
    if (checkedCount >= 3) {
      checkboxes.prop('disabled', true);
    }
  });
});
