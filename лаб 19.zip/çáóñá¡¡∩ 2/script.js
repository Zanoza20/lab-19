$(document).ready(function() {
  $('h2.head').css('background-color', 'green');
  $('h2.head .inner').css('font-size', '35px');
});
